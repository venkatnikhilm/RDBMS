﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ConsoleApp3
{
    class BankAccount
    {
        double balance;
        public BankAccount(double balance)
        {
            this.balance = balance;
        }
        public BankAccount()
        {
            this.balance = 500;
        }
        public double Getbalance()
        {
            return this.balance;
        }
    }
    class bankbal
    {
        public static void Main()
        {
            BankAccount b1 = new BankAccount(1000);
            Console.WriteLine($"Bal is{b1.Getbalance()}");
            BankAccount b2 = new BankAccount();
            Console.WriteLine($"Bal is{b2.Getbalance()}");
        }
    }
}
