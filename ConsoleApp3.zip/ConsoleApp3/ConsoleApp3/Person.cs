﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Person
    {
        public string name;
        DateTime dob;
        string Address;
        string marstatus;
        int age;
        string marry;
        public Person()
        {
            name = "abc";
            dob = DateTime.Today;
            Address = "Null";
            marstatus = "Unknown";
        }
        public Person(string nam, DateTime d, string add, string maristatus)
        {
            this.name = nam;
            this.dob = d;
            this.Address = add;
            this.marstatus = maristatus;
        }
        public string Getage()
        {
            DateTime today = DateTime.Today;
            this.age = today.Subtract(this.dob).Days;
            this.age = this.age / 365;
            return $"The age is {age} years ";
        }
        public bool CanMarry()
        {
            Console.WriteLine("1. If marital status is Single 2. For others");
            int ch = int.Parse(Console.ReadLine());
            switch (ch)
            {
                case 1:
                    if (this.age > 18)
                    {
                        this.marry = "can marry";
                        return true;
                    }
                    else
                    {
                        this.marry = "cannot marry";
                        return false;
                    }
                case 2:
                    this.marry = "cannot marry";
                    return false;
            }
            return false;
        }

        public override string ToString()
        {
            var date = dob.ToShortDateString();
            return $"{this.name} lives at {this.Address}, born on {date},{this.marstatus},{this.age} years old and {this.marry}";
        }




    }
    class person1test
    {
        public static void Main()
        {
            Person1 p = new Person1();
            Console.WriteLine(p.name);

            Person1 p1 = new Person1("Fred", new DateTime(2000, 12, 12), "21 Lancestar road", "Single");
            Console.WriteLine(p1.name);
            Console.WriteLine(p1.Getage());
            if (p1.CanMarry())
                Console.WriteLine($"Eligible to marry ");

            else Console.WriteLine("Not eligible to marry");
            Console.WriteLine(p1.ToString());

        }
    }
}
