﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Dimension
    {
        public int x { get; set; }
        public int y { get; set; }

        public Dimension()
        {
            x = 0;
            y = 0;
        }

        public Dimension(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public virtual double area()
        {
            return 0d;
        }
    }

    class Circle : Dimension
    {
        public Circle(int x_co, int y_co) : base(x_co, y_co)
        {

        }

        public override double area()
        {
            return Math.PI * this.x * this.x;
        }
        public string Display()
        {
            return $"CSA of Circle is {area()}";
        }
    }

    class Cylinder : Dimension
    {
        public Cylinder(int x_co, int y_co) : base(x_co, y_co)
        {

        }

        public override double area()
        {
            return (2 * Math.PI * this.x * this.x * this.y);
        }

        public string Display()
        {
            return $"CSA of cylinder is {area()}";
        }
    }

    class Sphere : Dimension
    {
        public Sphere(int x_co, int y_co) : base(x_co, y_co)
        {

        }

        public override double area()
        {
            return 4 * Math.PI * this.x * this.x;
        }

        public string Display()
        {
            return $"CSA of Sphere is {area()}";
        }
    }

    class TestDimension
    {
        public static void Main()
        {
            Circle c = new Circle(5, 5);
            Console.WriteLine(c.Display());
            Cylinder cy = new Cylinder(5, 5);
            Console.WriteLine(cy.Display());
            Sphere s = new Sphere(5, 5);
            Console.WriteLine(s.Display());

        }
    }

}
