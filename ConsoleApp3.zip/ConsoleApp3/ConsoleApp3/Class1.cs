﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class StudentDriver
    {
        public static void Main()
        {

            SciStudent s1 = new SciStudent { Rollno = 11, Name = "Sarah", Phyics = 90, Math = 87, Chem = 50 };
            ComStudent c1 = new ComStudent { Rollno = 20, Name = "Vijay", Economics = 61, Banking = 98, Accounts = 99 };
            Console.WriteLine(s1.GetAvg());
            Console.WriteLine(c1.GetAvg());
        }
    }
    class Student

    {
        public int Rollno { get; set; }
        public string Name { get; set; }

    }

    class SciStudent : Student

    {
        public int Phyics { get; set; }
        public int Math { get; set; }
        public int Chem { get; set; }

        public double GetAvg()
        {
            return (Phyics + Math + Chem);
        }


    }

    class ComStudent : Student

    {
        public int Economics { get; set; }
        public int Banking { get; set; }
        public int Accounts { get; set; }

        public double GetAvg()
        {
            return (Economics + Banking + Accounts);
        }


    }


}

