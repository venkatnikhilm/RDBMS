﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3

{
    class StaffMem
    {

        public StaffMem(string name, string address, string phone)
        {
            this.name = name;
            this.address = address;
            this.phone = phone;
        }

        public string name { get; set; }
        public string address { get; set; }
        public string phone { get; set; }

        public virtual double Pay()
        {
            return 10000;
        }

        public override string ToString()
        {
            return $"{name} lives at {address} having mobile no : {phone}";
        }
    }

    class Employee : StaffMem
    {
        public Employee(string name, string address, string phone, string socialSecurityNum, double payrate) : base(name, address, phone)
        {
            this.socialSecurityNum = socialSecurityNum;
            this.payrate = payrate;
        }

        public string socialSecurityNum { get; set; }
        public double payrate { get; set; }

        public override double Pay()
        {
            return base.Pay() + this.payrate;
        }

        public override string ToString()
        {
            return base.ToString() + $"{name}'s Social security no is {socialSecurityNum} with payrate of {payrate}";
        }
    }


    class Hourly : Employee
    {
        public Hourly(string name, string address, string phone, string socialSecurityNum, double payrate, int hours) : base(name, address, phone, socialSecurityNum, payrate)
        {
            this.hoursWorked = hoursWorked;
        }

        public int hoursWorked { get; set; }

        public void AddHours(int moreHours)
        {
            this.hoursWorked += moreHours;
        }

        public override string ToString()
        {
            return base.ToString() + $" Total hours worked = {hoursWorked}";
        }

        public override double Pay()
        {
            return base.Pay() + (payrate * hoursWorked);
        }
    }

    class Executive : Employee
    {
        public Executive(string name, string address, string phone, string socialSecurityNum, double payrate, double bonus) : base(name, address, phone, socialSecurityNum, payrate)
        {
            this.bonus = bonus;
        }
        public double bonus { get; set; }

        public void AwardBonus(double execBonus)
        {
            this.bonus += execBonus;
        }

        public override double Pay()
        {
            return base.Pay() + this.bonus;
        }

        public override string ToString()
        {
            return base.ToString() + $" having bonus {bonus}";
        }
    }


    class TestStaff
    {
        static void Main(string[] args)
        {
            Executive e = new Executive("tony", "new york", "1234-000-023", "123456789", 123, 5000);
            Console.WriteLine(e.ToString());
        }
    }
}