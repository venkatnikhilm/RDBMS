﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public interface CarInterface
    {
        void carCompany(string company);
        void carType(string type);
        void modelName(string model);

        void topSpeed(int speed);
    }

    public class Car : CarInterface
    {
        public void carCompany(string company)
        {
            Console.WriteLine($"The company of the car is {company}");
        }

        public void carType(string type)
        {
            Console.WriteLine($"the car is a {type}");
        }

        public void modelName(string model)
        {
            Console.WriteLine($"the car is a {model}");
        }

        public void topSpeed(int speed)
        {
            Console.WriteLine($"the car's top speed is  {speed}");
        }


    }

    public class TestCarInterface
    {
        public static void Main()
        {
            Car c1 = new Car();
            c1.carCompany("hyundai");
            c1.carType("SUV");
            c1.modelName("Creta");
            c1.topSpeed(180);
        }
    }
}
